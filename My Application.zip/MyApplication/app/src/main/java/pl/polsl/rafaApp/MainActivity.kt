package pl.polsl.rafaApp


import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

class MainActivity : AppCompatActivity() {

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,

        ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.tak, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.smutno, Toast.LENGTH_SHORT).show()
            }

        } else if (requestCode == 2) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.tak, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.smutno, Toast.LENGTH_SHORT).show()
            }

        }
    }
    fun toDMS(valuee: Double):String {
        val stopnie = valuee.toInt()
        val minutyFull = Math.abs((valuee - stopnie) * 60)
        val minuty = minutyFull.toInt()
        val sekundy = ((minutyFull - minuty) * 60)
        return "%d° %d'%2.3f\"".format(
            stopnie, minuty, sekundy
        )

    }

    private var startLocation: android.location.Location? = null
    private var endLocation: android.location.Location? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val b = findViewById<Button>(R.id.b)

        b.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.tak, Toast.LENGTH_SHORT).show()
            } else {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
            }
        }

        val b2 = findViewById<Button>(R.id.b2)
        b2.setOnClickListener {
            if (checkSelfPermission(
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                val cancellationTokenSource = CancellationTokenSource()
                val client = LocationServices.getFusedLocationProviderClient(this)
                client.getCurrentLocation(
                    Priority.PRIORITY_HIGH_ACCURACY,
                    null
                )
                    .addOnSuccessListener {
                        val latDMS = toDMS(it.latitude)
                        val lonDMS = toDMS(it.longitude)

                        Toast.makeText(
                            this,
                            "Szer.: $latDMS, Dł.: $lonDMS",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Błąd pobierania lokalizacji", Toast.LENGTH_SHORT)
                            .show()
                    }

            } else {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ),
                    2
                )
            }
        }
        val startBtn = findViewById<Button>(R.id.start)
        val endBtn = findViewById<Button>(R.id.end)
        val wynikText = findViewById<TextView>(R.id.wynik)
        val client = LocationServices.getFusedLocationProviderClient(this)

        startBtn.setOnClickListener {
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener {
                    startLocation = it
                    Toast.makeText(this, "Punkt A zapisany", Toast.LENGTH_SHORT).show()
                }
        }

        endBtn.setOnClickListener {
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener {
                    endLocation = it
                    if (startLocation != null && endLocation != null) {
                        val distance = startLocation!!.distanceTo(endLocation!!)
                        wynikText.text = "Przebyta droga: %.2f m".format(distance)
                    } else {
                        wynikText.text = "Brak danych o lokalizacji"
                    }
                }
        }
    }


}